#!/bin/bash


#Nicehash example run with GUI
./Etarminer  -url http://daggerhashimoto.eu.nicehash.com:3353 -wlt 16ZDFzikHiDF7EGDdHfgEb22Yr45JtVBfp.li21060 -wrk 1 -slcg g0 g1 -eml x -int 20  -exp 0 -ess 1 -wsz 64 

#Nicehash example run without GUI(create cach bit slow)
#./Etarminer  -url http://daggerhashimoto.eu.nicehash.com:3353 -wlt 16ZDFzikHiDF7EGDdHfgEb22Yr45JtVBfp.li21060 -wrk 1 -slcg g0 g1 -eml x -int 20  -exp 0 -ess 1 -wsz 64 -GUIDIS

#Dwarpool example
#Etarminer -url http://eth-ru.dwarfpool.com:8008 -wlt 0x98B079798640Bc175aF7E60b54b5cCec165dECC2/660 -wrk 1 -eml x -int 20 -wsz 128 -exp 0 -ess 1

#Suprnova example
#Etarminer -url http://etc-eu.suprnova.cc:3332 -wlt Etayson.worker1 -eml zachet07011981  -int 18 -wsz 128  -exp 0 -ess 1

#Coinotron example
#Etarminer -url http://coinotron.com:3344 -wlt Etar.worker1 -eml worker1 -int 20 -wsz 128  -exp 0 -ess 1

