#!/bin/bash
nvidia-smi -l 1
