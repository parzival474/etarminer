Etarminer v.1.8 LINUX VERSION
----------------
https://drive.google.com/drive/u/0/folders/0B9DK4ZXu8liUMkxpVkxaSHJGTms

This version is designed for mining ethereum through pool only (dwarfpool,ethermine.org and other)
Only cuda device support! For 64 bit linux.
Tested on UBUNTU 16.04 LTS

Fearures:
	- Dag file is not needed. It is created automatically on the GPU.
	- High speed DAG generation.
	- Fully writing from scratch of mining algorithm that gives the best result in comparison with the standard miner.
	- Failover support.
	- Remote monitor Etarstat

Using the Etarminer is free.

The values of local parameters overwrite the values of global!
Use this command line parameter:

-GUIDIS If you run miner without GUI

-url	Ethereum pool address and port. Only Stratum protocol is supported.
	symblol ":" is a separator between the address and port number.
	Ex, -url http://eth-ru.dwarfpool.com:8008
			
-wrk	Worker name, it is necessary for some pools.
	Ex, -wrk 1

-wlt	Wallet address. Need for dwarfpool for example.
	Ex, -wlt 0xF04f7978AA95be8D6ACa243b7150fe3384946592
			
-eml	Email address. Need for dwarfpool for example.
	Ex, -eml x

-int	Global. The intensity of mining. Use 18(default) for the comfort of the whole system.
	And 19,20 for the GPU more loads.
	Ex, -int 18 

-intg  	Local. The intensity for gpu specified in the list.
	Ex, -intg g0 18 g1 20 (gpu0 will work with intensity 18, gpu0 will work with intensity 20 remaining gpu
	on global parameter -int or default.	

-wsz	Global. For all the gpu.
	The number of threads per block. Always a multiple of 32. Using the value 64,128(default),256
	Ex, -wsz 128
			
-wszg	Local. The number of threads per unit for gpu specified in the list.
	Ex, -wszg g0 64 g1 128 (gpu0 will work with 64 threads per block, gpu0 will work with 128 threads per block, tremaining gpu
	on global parameter -wsz or default.

-tsmg	Local. Which architecture to customize the kernel the listed gpu. The value of the two numbers.
	By default, the kernel of each gpu receives a pointer to equal its compute capality. T.e. Geforce gtx 1070,
	which has compute capability 6.1, get a pointer 61.
	If for some reason gpu does not start and the error "FATAL ERROR GPU" appears. Set the value -tsmg
	gpu selected to a smaller value. This applies to cards with Pascal architecture.
	Ex, -tsmg g0 53

-slcg	Local. Use only the specified GPU for mining.
	Ex, -slcg g0 g3 use only gpu1 and gpu3 for mining

-ess	Global. Enable / disable the built-in statistics server. The default setting (enable) is equivalent to value -ess 1
	Ex, -ess 0 disables server statistics

-pss	Global. Change the port for the miner server statistics. The default port 10001
	Ex, -pss 8000 Use port 8000 for the statistics server.



Command line example runs .bat file:

Example for dwarfpool
	Etarminer  -url http://eth-ru.dwarfpool.com:8008 -wlt YOURWALLET -wrk 1 -eml x 
	If you need to specify worker`s name, enter it immediately after your wallet separated by a "/"
	Example for the name worker`s 25:
	Etarminer  -url http://eth-ru.dwarfpool.com:8008 -wlt YOURWALLET/25 -wrk 1 -eml x 

Example for coinmine:
	Etarminer  -url http://eth.coinmine.pl:4000 -wlt LOGIN.WORKER -eml password 

Example for ethermine:
	Etarminer  -url http://eu1.ethermine.org:4444 -wlt YOURWALLET -wrk 1 -eml x 
	If you need to specify worker`s name, enter it immediately after your wallet separated by a "."
	Example for the name worker`s 25:
	Etarminer  -url http://eu1.ethermine.org:4444 -wlt YOURWALLET.25 -wrk 1 -eml x

Example for coinotron:	
	Etarminer  -url http://coinotron.com:3344 -wlt LOGIN.WORKER -eml PASSWORD

Example for digger:
	Etarminer  -url http://digger.ws:8008 -wlt YOURWALLET -wrk 1 -eml x 

Example for minergate:
	Etarminer  -url http://eth.pool.minergate.com:45791 -wlt YOUREMAIL -wrk 1 -eml x

Example for suprnova:
	Etarminer  http://etc-eu.suprnova.cc:3333 LOGIN.WORKER -eml password 

Example for nicehash:
	Etarminer -url http://daggerhashimoto.eu.nicehash.com:3353 -wlt BITCOINWALLET.WORKER -eml 1

To dynamically change the intensity of mining:
	1) using the keyboard keys <g> to select the desired GPU
	2) Use the <+> key to increase the intensity and press <-> to decrease

Using the app to collect statistics Etarstat:

        Add miner and in open window set:
           <Name> name your miner
           <Ip>  ip adress miner in IPv4 format
           <Port> port miner

       	If need use right click menu:
           <Edit> to edit miner settings
           <Remove>  to remove miner from list
           <View console> to view console data miner
	   <restart miner> to restart miner with parameters
           <Quit> to quit from aplication

        Miner background color mean:
           <red> no connection with miner
           <green> conection with miner and pool establish
           <orange> conection with miner establish, but pool is not answered

        Use checkbox to disable/enable sound notification
        Settings save when aplication close
	
	When you select a miner from the list at the bottom of the window you will see command line parameters,
	which run miner was. if necessary, add to change in settings, and restart the miner through the menu.
